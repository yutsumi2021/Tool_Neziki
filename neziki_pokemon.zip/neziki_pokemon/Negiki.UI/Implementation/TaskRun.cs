﻿using Negiki.UI.function;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negiki.UI.Implementation
{
    /// <summary>
    /// 非同期処理実行用のクラス
    /// </summary>
    public class TaskRun : ITaskRun
    {
        public string _Progress_text { get; set; } 
        public int Progress { get; set; }

        private Action<object> Action { get; set; }

        public TaskRun(Action<object> action)
        {
            Action = action;
        }

        /// <summary>
        /// 非同期処理を実行します。
        /// </summary>
        private async void RunMethodASync()
        {
            await Task.Run(() => Dowork());
        }
        public void Dowork()
        {
            
        }

        public Func<object, int, object> Dowork(IProgress<int> i, object obj)
        {
            throw new NotImplementedException();
        }

        public void ShowProgress(int i)
        {
            throw new NotImplementedException();
        }

        
    }
}
