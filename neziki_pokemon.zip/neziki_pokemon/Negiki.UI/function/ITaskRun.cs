﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negiki.UI.function
{
   public interface ITaskRun
    {
        /// <summary>
        /// 処理を実行します
        /// </summary>
        void Dowork();

        /// <summary>
        /// 処理を実行します。(進捗を返す）
        /// </summary>
        /// <param name="i"></param>
        /// <param name="obj"></param>
        /// <returns></returns>
        Func<object, int, object> Dowork(IProgress<int> i, object obj);

        /// <summary>
        /// 進捗を表示します
        /// </summary>
        /// <param name="i"></param>
        void ShowProgress(int i);
    }
}
