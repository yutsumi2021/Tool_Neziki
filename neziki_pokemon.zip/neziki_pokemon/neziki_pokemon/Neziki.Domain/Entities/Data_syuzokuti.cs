﻿namespace Neziki.Domain.Entities
{
    public class Data_syuzokuti
    {
        public string K_ID { get; set; }
        public string Name { get; set; }
        public int HP { get; set; }
        public int A { get; set; }
        public int B { get; set; }
        public int C { get; set; }
        public int D { get; set; }
        public int S { get; set; }
    }
}
